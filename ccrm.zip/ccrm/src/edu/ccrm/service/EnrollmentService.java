package edu.ccrm.service;

import edu.ccrm.domain.*;
import java.util.*;

public class EnrollmentService {

    private final List<Enrollment> enrollments = new ArrayList<>();

    // Enroll a student in a course for a semester
    public void enrollStudent(Student student, Course course, Semester semester) {
        Enrollment enrollment = new Enrollment(student, course, semester);
        enrollments.add(enrollment);
    }

    // Assign grade to a student's enrollment
    public void assignGrade(Student student, Course course, Grade grade) {
        for (Enrollment e : enrollments) {
            if (e.getStudent().equals(student) && e.getCourse().equals(course)) {
                e.setGrade(grade);
                return;
            }
        }
        System.out.println("❌ Enrollment not found for this student/course.");
    }

    // Get all enrollments for a specific student
    public List<Enrollment> getEnrollmentsByStudent(Student student) {
        List<Enrollment> result = new ArrayList<>();
        for (Enrollment e : enrollments) {
            if (e.getStudent().equals(student)) {
                result.add(e);
            }
        }
        return result;
    }

    // Optional: get all enrollments (for debugging)
    public List<Enrollment> getAllEnrollments() {
        return new ArrayList<>(enrollments);
    }
}



