package edu.ccrm.service;

import edu.ccrm.domain.*;
import java.io.*;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class FileService {

    private static final String DATA_DIR = "data";
    private static final String STUDENTS_FILE = DATA_DIR + "/students.csv";
    private static final String COURSES_FILE = DATA_DIR + "/courses.csv";
    private static final String ENROLLMENTS_FILE = DATA_DIR + "/enrollments.csv";

    public FileService() {
        try {
            Files.createDirectories(Paths.get(DATA_DIR));
        } catch (IOException e) {
            System.err.println("❌ Could not create data directory: " + e.getMessage());
        }
    }

    // === Export Students ===
    public void exportStudents(List<Student> students) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(STUDENTS_FILE))) {
            for (Student s : students) {
                pw.println(s.getId() + "," + s.getRegNo() + "," + s.getName() + "," + s.getEmail() + "," + s.isActive());
            }
            System.out.println("✅ Students exported to " + STUDENTS_FILE);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // === Import Students ===
    public List<Student> importStudents() {
        List<Student> students = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(STUDENTS_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 4) {
                    int id = Integer.parseInt(parts[0]);
                    String regNo = parts[1];
                    String name = parts[2];
                    String email = parts[3];
                    Student s = new Student(id, regNo, name, email);
                    if (parts.length >= 5 && parts[4].equals("false")) {
                        s.deactivate();
                    }
                    students.add(s);
                }
            }
        } catch (IOException e) {
            System.out.println("⚠ No existing students file, starting fresh.");
        }
        return students;
    }

    // === Export Courses ===
    public void exportCourses(List<Course> courses) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(COURSES_FILE))) {
            for (Course c : courses) {
                pw.println(c.getCode() + "," + c.getTitle() + "," + c.getCredits() + "," +
                           c.getInstructor() + "," + c.getDepartment() + "," + c.isActive());
            }
            System.out.println("✅ Courses exported to " + COURSES_FILE);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // === Import Courses ===
    public List<Course> importCourses() {
        List<Course> courses = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(COURSES_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 5) {
                    String code = parts[0];
                    String title = parts[1];
                    int credits = Integer.parseInt(parts[2]);
                    String instructor = parts[3];
                    String department = parts[4];
                    Course c = new Course(code, title, credits, instructor, department);
                    if (parts.length >= 6 && parts[5].equals("false")) {
                        c.deactivate();
                    }
                    courses.add(c);
                }
            }
        } catch (IOException e) {
            System.out.println("⚠ No existing courses file, starting fresh.");
        }
        return courses;
    }

    // === Export Enrollments ===
    public void exportEnrollments(List<Enrollment> enrollments) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(ENROLLMENTS_FILE))) {
            for (Enrollment e : enrollments) {
                String grade = (e.getGrade() == null ? "N/A" : e.getGrade().name());
                pw.println(e.getStudent().getId() + "," +
                           e.getCourse().getCode() + "," +
                           e.getSemester().name() + "," +
                           grade);
            }
            System.out.println("✅ Enrollments exported to " + ENROLLMENTS_FILE);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // === Import Enrollments ===
    public List<Enrollment> importEnrollments(List<Student> students, List<Course> courses) {
        List<Enrollment> enrollments = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(ENROLLMENTS_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 3) {
                    int studentId = Integer.parseInt(parts[0]);
                    String courseCode = parts[1];
                    Semester semester = Semester.valueOf(parts[2]);

                    Student student = students.stream().filter(s -> s.getId() == studentId).findFirst().orElse(null);
                    Course course = courses.stream().filter(c -> c.getCode().equalsIgnoreCase(courseCode)).findFirst().orElse(null);

                    if (student != null && course != null) {
                        Enrollment e = new Enrollment(student, course, semester);
                        if (parts.length >= 4 && !parts[3].equals("N/A")) {
                            e.setGrade(Grade.valueOf(parts[3]));
                        }
                        enrollments.add(e);
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("⚠ No existing enrollments file, starting fresh.");
        }
        return enrollments;
    }

    // === Backup Data Folder ===
    public void backupData() {
        try {
            String backupDirName = "backup_" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
            Path backupDir = Paths.get("backup", backupDirName);
            Files.createDirectories(backupDir);

            Files.walk(Paths.get(DATA_DIR)).forEach(src -> {
                try {
                    Path dest = backupDir.resolve(Paths.get(DATA_DIR).relativize(src));
                    if (Files.isDirectory(src)) {
                        Files.createDirectories(dest);
                    } else {
                        Files.copy(src, dest, StandardCopyOption.REPLACE_EXISTING);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });

            System.out.println("✅ Backup created at " + backupDir.toAbsolutePath());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}


