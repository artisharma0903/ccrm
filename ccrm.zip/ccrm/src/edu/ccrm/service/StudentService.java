// package edu.ccrm.service;

// import edu.ccrm.domain.*;
// import java.util.*;

// public class StudentService {
//     private final List<Student> students = new ArrayList<>();

//     public void addStudent(Student student) {
//         students.add(student);
//     }

//     public List<Student> listStudents() {
//         return students;
//     }

//     public Student findStudentById(int id) {
//         for (Student s : students) {
//             if (s.getId() == id) return s;
//         }
//         return null;
//     }
// }
package edu.ccrm.service;

import edu.ccrm.domain.*;
import java.util.*;

public class StudentService {
    private final List<Student> students = new ArrayList<>();

    public void addStudent(Student student) {
        students.add(student);
    }

    public List<Student> listStudents() {
        return students;
    }

    public Student findStudentById(int id) {
        for (Student s : students) {
            if (s.getId() == id) return s;
        }
        return null;
    }

    // ✅ Needed for Import
    public void setStudents(List<Student> imported) {
        this.students.clear();
        this.students.addAll(imported);
    }
}



