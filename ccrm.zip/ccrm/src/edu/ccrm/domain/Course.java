package edu.ccrm.domain;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Objects;

public class Course implements Serializable {
    private static final long serialVersionUID = 1L;

    private String code;
    private String title;
    private int credits;
    private String instructor;
    private String department;
    private boolean active = true;
    private LocalDate createdOn;

    public Course(String code, String title, int credits, String instructor, String department) {
        this.code = code;
        this.title = title;
        this.credits = credits;
        this.instructor = instructor;
        this.department = department;
        this.createdOn = LocalDate.now();
    }

    // === Getters ===
    public String getCode() { return code; }
    public String getTitle() { return title; }
    public int getCredits() { return credits; }
    public String getInstructor() { return instructor; }
    public String getDepartment() { return department; }
    public boolean isActive() { return active; }
    public LocalDate getCreatedOn() { return createdOn; }

    // === Business Methods ===
    public void deactivate() { this.active = false; }

    public void updateCourse(String newTitle, String newInstructor, String newDepartment) {
        this.title = newTitle;
        this.instructor = newInstructor;
        this.department = newDepartment;
    }

    // === toString() ===
    @Override
    public String toString() {
        return "Course [code=" + code +
               ", title=" + title +
               ", credits=" + credits +
               ", instructor=" + instructor +
               ", department=" + department +
               ", active=" + active +
               ", createdOn=" + createdOn +
               "]";
    }

    // === equals & hashCode (based on course code) ===
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Course)) return false;
        Course c = (Course) o;
        return code.equalsIgnoreCase(c.code);
    }

    @Override
    public int hashCode() {
        return Objects.hash(code.toLowerCase());
    }
}
