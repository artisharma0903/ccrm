package edu.ccrm.util;

import java.io.*;
import java.nio.file.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class FileUtils {

    // Save list of strings to CSV file
    public static void saveToCSV(List<String> lines, String filePath) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            for (String line : lines) {
                writer.write(line);
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("❌ Error writing to file: " + e.getMessage());
        }
    }

    // Load CSV lines into a list
    public static List<String> loadFromCSV(String filePath) {
        List<String> lines = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                lines.add(line);
            }
        } catch (IOException e) {
            System.out.println("⚠ No existing data in " + filePath + " (fresh start).");
        }
        return lines;
    }

    // Create a backup of a file with timestamp
    public static void backupFile(String filePath, String backupDir) {
        try {
            Files.createDirectories(Paths.get(backupDir));
            String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
            Path source = Paths.get(filePath);
            Path dest = Paths.get(backupDir, source.getFileName().toString() + "_" + timestamp + ".bak");
            Files.copy(source, dest, StandardCopyOption.REPLACE_EXISTING);
            System.out.println("✅ Backup created: " + dest);
        } catch (IOException e) {
            System.out.println("⚠ Backup skipped (file may not exist yet).");
        }
    }
}
