// package edu.ccrm.service;

// import edu.ccrm.domain.*;
// import java.util.List;

// public class TranscriptService {

//     private final EnrollmentService enrollmentService;

//     public TranscriptService(EnrollmentService enrollmentService) {
//         this.enrollmentService = enrollmentService;
//     }

//     public void showTranscript(Student student) {
//         List<Enrollment> enrollments = enrollmentService.getEnrollmentsByStudent(student);

//         System.out.println("\nTranscript for " + student.getName() + " (" + student.getRegNo() + ")");
//         if (enrollments.isEmpty()) {
//             System.out.println("No courses enrolled yet.");
//             return;
//         }

//         System.out.printf("%-10s %-25s %-10s %-5s%n", "Code", "Title", "Semester", "Grade");
//         System.out.println("----------------------------------------------------");

//         for (Enrollment e : enrollments) {
//             String gradeStr = (e.getGrade() == null ? "N/A" : e.getGrade().name());
//             System.out.printf("%-10s %-25s %-10s %-5s%n",
//                     e.getCourse().getCode(),
//                     e.getCourse().getTitle(),
//                     e.getSemester(),
//                     gradeStr);
//         }
//     }
// }
package edu.ccrm.service;

import edu.ccrm.domain.*;
import java.util.List;

public class TranscriptService {

    private final EnrollmentService enrollmentService;

    public TranscriptService(EnrollmentService enrollmentService) {
        this.enrollmentService = enrollmentService;
    }

    public void showTranscript(Student student) {
        List<Enrollment> enrollments = enrollmentService.getEnrollmentsByStudent(student);

        System.out.println("\nTranscript for " + student.getName() + " (" + student.getRegNo() + ")");
        if (enrollments.isEmpty()) {
            System.out.println("No courses enrolled yet.");
            return;
        }

        System.out.printf("%-10s %-25s %-10s %-5s%n", "Code", "Title", "Semester", "Grade");
        System.out.println("----------------------------------------------------");

        double totalPoints = 0;
        int totalCredits = 0;

        for (Enrollment e : enrollments) {
            String gradeStr = (e.getGrade() == null ? "In Progress" : e.getGrade().name());
            System.out.printf("%-10s %-25s %-10s %-5s%n",
                    e.getCourse().getCode(),
                    e.getCourse().getTitle(),
                    e.getSemester(),
                    gradeStr);

            if (e.getGrade() != null) {
                totalPoints += e.getGrade().getPoints() * e.getCourse().getCredits();
                totalCredits += e.getCourse().getCredits();
            }
        }

        double gpa = (totalCredits == 0) ? 0.0 : totalPoints / totalCredits;
        System.out.println("----------------------------------------------------");
        System.out.printf("Total Credits: %d | GPA: %.2f%n", totalCredits, gpa);
    }
}

