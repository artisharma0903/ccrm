// package edu.ccrm.cli;

// import edu.ccrm.domain.*;
// import edu.ccrm.service.*;
// import java.util.Scanner;

// public class MainApp {

//     public static void main(String[] args) {
//         Scanner sc = new Scanner(System.in);

//         // Services
//         StudentService studentService = new StudentService();
//         CourseService courseService = new CourseService();
//         EnrollmentService enrollmentService = new EnrollmentService();
//         TranscriptService transcriptService = new TranscriptService(enrollmentService);

//         while (true) {
//             System.out.println("\n=== Campus Course & Records Manager ===");
//             System.out.println("1. Add Student");
//             System.out.println("2. List Students");
//             System.out.println("3. Add Course");
//             System.out.println("4. List Courses");
//             System.out.println("5. Enroll Student in Course");
//             System.out.println("6. Assign Grade");
//             System.out.println("7. Show Transcript");
//             System.out.println("8. Exit");
//             System.out.print("Enter choice: ");

//             int choice = sc.nextInt();
//             sc.nextLine(); // consume newline

//             switch (choice) {
//                 case 1 -> addStudent(sc, studentService);
//                 case 2 -> listStudents(studentService);
//                 case 3 -> addCourse(sc, courseService);
//                 case 4 -> listCourses(courseService);
//                 case 5 -> enrollStudent(sc, studentService, courseService, enrollmentService);
//                 case 6 -> assignGrade(sc, studentService, courseService, enrollmentService);
//                 case 7 -> showTranscript(sc, studentService, transcriptService);
//                 case 8 -> {
//                     System.out.println("👋 Exiting...");
//                     sc.close();
//                     return;
//                 }
//                 default -> System.out.println("❌ Invalid choice");
//             }
//         }
//     }

//     private static void addStudent(Scanner sc, StudentService service) {
//         System.out.print("Enter ID: "); int id = sc.nextInt(); sc.nextLine();
//         System.out.print("Enter RegNo: "); String regNo = sc.nextLine();
//         System.out.print("Enter Name: "); String name = sc.nextLine();
//         System.out.print("Enter Email: "); String email = sc.nextLine();
//         service.addStudent(new Student(id, regNo, name, email));
//         System.out.println("✅ Student added!");
//     }

//     private static void listStudents(StudentService service) {
//         System.out.println("Students:");
//         service.listStudents().forEach(System.out::println);
//     }

//     private static void addCourse(Scanner sc, CourseService service) {
//         System.out.print("Enter Code: "); String code = sc.nextLine();
//         System.out.print("Enter Title: "); String title = sc.nextLine();
//         System.out.print("Enter Credits: "); int credits = sc.nextInt(); sc.nextLine();
//         service.addCourse(new Course(code, title, credits));
//         System.out.println("✅ Course added!");
//     }

//     private static void listCourses(CourseService service) {
//         System.out.println("Courses:");
//         service.listCourses().forEach(System.out::println);
//     }

//     private static void enrollStudent(Scanner sc, StudentService studentService,
//                                       CourseService courseService, EnrollmentService enrollmentService) {
//         System.out.print("Enter Student ID: "); int sid = sc.nextInt(); sc.nextLine();
//         Student student = studentService.findStudentById(sid);
//         if (student == null) { System.out.println("❌ Student not found."); return; }

//         System.out.print("Enter Course Code: "); String ccode = sc.nextLine();
//         Course course = courseService.findCourseByCode(ccode);
//         if (course == null) { System.out.println("❌ Course not found."); return; }

//         System.out.print("Enter Semester (SPRING/SUMMER/FALL/WINTER): "); 
//         String semStr = sc.nextLine().toUpperCase();
//         try {
//             Semester semester = Semester.valueOf(semStr);
//             enrollmentService.enrollStudent(student, course, semester);
//             System.out.println("✅ Enrollment successful!");
//         } catch (IllegalArgumentException e) {
//             System.out.println("❌ Invalid semester. Use SPRING, SUMMER, FALL, or WINTER.");
//         }
//     }

//     private static void assignGrade(Scanner sc, StudentService studentService,
//                                     CourseService courseService, EnrollmentService enrollmentService) {
//         System.out.print("Enter Student ID: "); int sid = sc.nextInt(); sc.nextLine();
//         Student student = studentService.findStudentById(sid);
//         if (student == null) { System.out.println("❌ Student not found."); return; }

//         System.out.print("Enter Course Code: "); String ccode = sc.nextLine();
//         Course course = courseService.findCourseByCode(ccode);
//         if (course == null) { System.out.println("❌ Course not found."); return; }

//         System.out.print("Enter Grade (A/B/C/D/F): "); String gradeStr = sc.nextLine().toUpperCase();
//         try {
//             Grade grade = Grade.valueOf(gradeStr);
//             enrollmentService.assignGrade(student, course, grade);
//             System.out.println("✅ Grade assigned!");
//         } catch (IllegalArgumentException e) {
//             System.out.println("❌ Invalid grade. Use A, B, C, D, or F.");
//         }
//     }

//     private static void showTranscript(Scanner sc, StudentService studentService,
//                                        TranscriptService transcriptService) {
//         System.out.print("Enter Student ID: "); int sid = sc.nextInt(); sc.nextLine();
//         Student student = studentService.findStudentById(sid);
//         if (student == null) { System.out.println("❌ Student not found."); return; }

//         transcriptService.showTranscript(student);
//     }
// }
package edu.ccrm.cli;

import edu.ccrm.domain.*;
import edu.ccrm.service.*;
import java.util.Scanner;

public class MainApp {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        StudentService studentService = new StudentService();
        CourseService courseService = new CourseService();
        EnrollmentService enrollmentService = new EnrollmentService();
        TranscriptService transcriptService = new TranscriptService(enrollmentService);
        FileService fileService = new FileService();

        while (true) {
            System.out.println("\n=== Campus Course & Records Manager ===");
            System.out.println("1. Add Student");
            System.out.println("2. List Students");
            System.out.println("3. Add Course");
            System.out.println("4. List Courses");
            System.out.println("5. Enroll Student in Course");
            System.out.println("6. Assign Grade");
            System.out.println("7. Show Transcript");
            System.out.println("8. Update Student");
            System.out.println("9. Deactivate Student");
            System.out.println("10. Update Course");
            System.out.println("11. Deactivate Course");
            System.out.println("12. Export Data");
            System.out.println("13. Import Data");
            System.out.println("14. Backup Data");
            System.out.println("15. Exit");
            System.out.print("Enter choice: ");

            int choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1 -> {
                    System.out.print("Enter ID: ");
                    int id = sc.nextInt(); sc.nextLine();
                    System.out.print("Enter RegNo: ");
                    String regNo = sc.nextLine();
                    System.out.print("Enter Name: ");
                    String name = sc.nextLine();
                    System.out.print("Enter Email: ");
                    String email = sc.nextLine();
                    studentService.addStudent(new Student(id, regNo, name, email));
                    System.out.println("✅ Student added!");
                }
                case 2 -> {
                    System.out.println("Students:");
                    studentService.listStudents().forEach(System.out::println);
                }
                case 3 -> {
                    System.out.print("Enter Code: ");
                    String code = sc.nextLine();
                    System.out.print("Enter Title: ");
                    String title = sc.nextLine();
                    System.out.print("Enter Credits: ");
                    int credits = sc.nextInt(); sc.nextLine();
                    courseService.addCourse(new Course(code, title, credits));
                    System.out.println("✅ Course added!");
                }
                case 4 -> {
                    System.out.println("Courses:");
                    courseService.listCourses().forEach(System.out::println);
                }
                case 5 -> {
                    System.out.print("Enter Student ID: ");
                    int sid = sc.nextInt(); sc.nextLine();
                    Student student = studentService.findStudentById(sid);
                    if (student == null) {
                        System.out.println("❌ Student not found.");
                        break;
                    }
                    System.out.print("Enter Course Code: ");
                    String ccode = sc.nextLine();
                    Course course = courseService.findCourseByCode(ccode);
                    if (course == null) {
                        System.out.println("❌ Course not found.");
                        break;
                    }
                    System.out.print("Enter Semester (SPRING/SUMMER/FALL/WINTER): ");
                    String semStr = sc.nextLine().toUpperCase();
                    try {
                        Semester semester = Semester.valueOf(semStr);
                        enrollmentService.enrollStudent(student, course, semester);
                        System.out.println("✅ Enrollment successful!");
                    } catch (IllegalArgumentException e) {
                        System.out.println("❌ Invalid semester.");
                    }
                }
                case 6 -> {
                    System.out.print("Enter Student ID: ");
                    int sid = sc.nextInt(); sc.nextLine();
                    Student student = studentService.findStudentById(sid);
                    if (student == null) {
                        System.out.println("❌ Student not found.");
                        break;
                    }
                    System.out.print("Enter Course Code: ");
                    String ccode = sc.nextLine();
                    Course course = courseService.findCourseByCode(ccode);
                    if (course == null) {
                        System.out.println("❌ Course not found.");
                        break;
                    }
                    System.out.print("Enter Grade (A/B/C/D/F): ");
                    String gradeStr = sc.nextLine().toUpperCase();
                    try {
                        Grade grade = Grade.valueOf(gradeStr);
                        enrollmentService.assignGrade(student, course, grade);
                        System.out.println("✅ Grade assigned!");
                    } catch (IllegalArgumentException e) {
                        System.out.println("❌ Invalid grade.");
                    }
                }
                case 7 -> {
                    System.out.print("Enter Student ID: ");
                    int sid = sc.nextInt(); sc.nextLine();
                    Student student = studentService.findStudentById(sid);
                    if (student == null) {
                        System.out.println("❌ Student not found.");
                        break;
                    }
                    transcriptService.showTranscript(student);
                }
                case 8 -> {
                    System.out.print("Enter Student ID: ");
                    int sid = sc.nextInt(); sc.nextLine();
                    Student student = studentService.findStudentById(sid);
                    if (student == null) {
                        System.out.println("❌ Student not found.");
                        break;
                    }
                    System.out.print("Enter new name: ");
                    String newName = sc.nextLine();
                    System.out.print("Enter new email: ");
                    String newEmail = sc.nextLine();
                    student.updateProfile(newName, newEmail);
                    System.out.println("✅ Student updated!");
                }
                case 9 -> {
                    System.out.print("Enter Student ID: ");
                    int sid = sc.nextInt(); sc.nextLine();
                    Student student = studentService.findStudentById(sid);
                    if (student == null) {
                        System.out.println("❌ Student not found.");
                        break;
                    }
                    student.deactivate();
                    System.out.println("✅ Student deactivated!");
                }
                case 10 -> {
                    System.out.print("Enter Course Code: ");
                    String ccode = sc.nextLine();
                    System.out.print("Enter new title: ");
                    String newTitle = sc.nextLine();
                    boolean updated = courseService.updateCourse(ccode, newTitle);
                    if (updated) System.out.println("✅ Course updated!");
                    else System.out.println("❌ Course not found.");
                }
                case 11 -> {
                    System.out.print("Enter Course Code: ");
                    String ccode = sc.nextLine();
                    boolean deactivated = courseService.deactivateCourse(ccode);
                    if (deactivated) System.out.println("✅ Course deactivated!");
                    else System.out.println("❌ Course not found or already inactive.");
                }
                case 12 -> {
                    fileService.exportStudents(studentService.listStudents());
                    fileService.exportCourses(courseService.listCourses());
                    fileService.exportEnrollments(enrollmentService.getAllEnrollments());
                    System.out.println("✅ Data exported!");
                }
                case 13 -> {
                    var importedStudents = fileService.importStudents();
                    var importedCourses = fileService.importCourses();
                    var importedEnrollments = fileService.importEnrollments(importedStudents, importedCourses);

                    studentService.setStudents(importedStudents);
                    courseService.setCourses(importedCourses);
                    enrollmentService.setEnrollments(importedEnrollments);

                    System.out.println("✅ Data imported!");
                }
                case 14 -> {
                    fileService.backupData();
                }
                case 15 -> {
                    System.out.println("👋 Exiting...");
                    sc.close();
                    return;
                }
                default -> System.out.println("❌ Invalid choice");
            }
        }
    }
}
