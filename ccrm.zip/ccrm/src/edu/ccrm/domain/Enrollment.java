package edu.ccrm.domain;

import java.io.Serializable;

public class Enrollment implements Serializable {

    private static final long serialVersionUID = 1L;

    private Student student;
    private Course course;
    private Semester semester;
    private Grade grade; // can be null initially

    public Enrollment(Student student, Course course, Semester semester) {
        this.student = student;
        this.course = course;
        this.semester = semester;
        this.grade = null; // initially no grade
    }

    // Getters
    public Student getStudent() { return student; }
    public Course getCourse() { return course; }
    public Semester getSemester() { return semester; }
    public Grade getGrade() { return grade; }

    // Setter for grade
    public void setGrade(Grade grade) { this.grade = grade; }

    @Override
    public String toString() {
        String gradeStr = (grade == null ? "N/A" : grade.name());
        return student.getName() + " - " + course.getCode() + " (" + course.getTitle() + "), "
                + semester + ", Grade: " + gradeStr;
    }
}

