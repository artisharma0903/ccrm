// package edu.ccrm.domain;

// import java.io.Serializable;
// import java.util.ArrayList;
// import java.util.List;
// import java.util.Objects;

// public class Student extends Person implements Serializable {
//     private static final long serialVersionUID = 1L;

//     private String regNo;
//     private boolean active = true;
//     private List<Course> enrolledCourses = new ArrayList<>();

//     public Student(int id, String regNo, String name, String email) {
//         super(id, name, email);
//         this.regNo = regNo;
//     }

//     @Override
//     public String getRole() {
//         return "Student";
//     }

//     public String getRegNo() { return regNo; }
//     public boolean isActive() { return active; }
//     public void deactivate() { this.active = false; }

//     public void enroll(Course c) { enrolledCourses.add(c); }
//     public List<Course> getEnrolledCourses() { return enrolledCourses; }

//     @Override
//     public String toString() {
//         StringBuilder sb = new StringBuilder();
//         sb.append("Student [id=").append(id)
//           .append(", regNo=").append(regNo)
//           .append(", name=").append(fullName)
//           .append(", email=").append(email)
//           .append(", active=").append(active)
//           .append("]\n");

//         if (enrolledCourses.isEmpty()) {
//             sb.append("  Enrolled Courses: None");
//         } else {
//             sb.append("  Enrolled Courses: ");
//             for (Course c : enrolledCourses) {
//                 sb.append(c.getCode()).append(" ");
//             }
//         }
//         return sb.toString();
//     }

//     // === Important: equals & hashCode based on student ID ===
//     @Override
//     public boolean equals(Object o) {
//         if (this == o) return true;
//         if (!(o instanceof Student)) return false;
//         Student s = (Student) o;
//         return id == s.id;
//     }

//     @Override
//     public int hashCode() {
//         return Objects.hash(id);
//     }
// }
package edu.ccrm.domain;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Student extends Person implements Serializable {
    private static final long serialVersionUID = 1L;

    private String regNo;
    private boolean active = true;
    private LocalDate enrollmentDate;
    private LocalDate deactivationDate;
    private List<Course> enrolledCourses = new ArrayList<>();

    public Student(int id, String regNo, String name, String email) {
        super(id, name, email);
        this.regNo = regNo;
        this.enrollmentDate = LocalDate.now(); // set date when created
    }

    @Override
    public String getRole() { return "Student"; }

    public String getRegNo() { return regNo; }
    public boolean isActive() { return active; }
    public LocalDate getEnrollmentDate() { return enrollmentDate; }
    public LocalDate getDeactivationDate() { return deactivationDate; }

    public void deactivate() {
        this.active = false;
        this.deactivationDate = LocalDate.now();
    }

    public void updateProfile(String newName, String newEmail) {
        this.fullName = newName;
        this.email = newEmail;
    }

    public void enroll(Course c) { enrolledCourses.add(c); }
    public List<Course> getEnrolledCourses() { return enrolledCourses; }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Student [id=").append(id)
          .append(", regNo=").append(regNo)
          .append(", name=").append(fullName)
          .append(", email=").append(email)
          .append(", active=").append(active)
          .append(", enrolledOn=").append(enrollmentDate)
          .append(", deactivatedOn=").append(deactivationDate == null ? "-" : deactivationDate)
          .append("]\n");

        if (enrolledCourses.isEmpty()) {
            sb.append("  Enrolled Courses: None");
        } else {
            sb.append("  Enrolled Courses: ");
            for (Course c : enrolledCourses) {
                sb.append(c.getCode()).append(" ");
            }
        }
        return sb.toString();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Student)) return false;
        Student s = (Student) o;
        return id == s.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}


