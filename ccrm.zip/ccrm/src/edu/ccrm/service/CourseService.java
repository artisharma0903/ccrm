// package edu.ccrm.service;

// import edu.ccrm.domain.*;
// import java.util.*;

// public class CourseService {
//     private final List<Course> courses = new ArrayList<>();

//     public void addCourse(Course course) {
//         courses.add(course);
//     }

//     public List<Course> listCourses() {
//         return courses;
//     }

//     public Course findCourseByCode(String code) {
//         for (Course c : courses) {
//             if (c.getCode().equalsIgnoreCase(code)) return c;
//         }
//         return null;
//     }
// }
package edu.ccrm.service;

import edu.ccrm.domain.*;
import java.util.*;

public class CourseService {
    private final List<Course> courses = new ArrayList<>();

    // === Add course (check duplicates) ===
    public void addCourse(Course course) {
        if (!courses.contains(course)) {
            courses.add(course);
        } else {
            System.out.println("❌ Course already exists with code: " + course.getCode());
        }
    }

    // === List all courses ===
    public List<Course> listCourses() {
        return new ArrayList<>(courses);
    }

    // === Find by course code ===
    public Course findCourseByCode(String code) {
        for (Course c : courses) {
            if (c.getCode().equalsIgnoreCase(code)) return c;
        }
        return null;
    }

    // === Update course details ===
    public boolean updateCourse(String code, String newTitle, String newInstructor, String newDepartment) {
        Course course = findCourseByCode(code);
        if (course != null) {
            course.updateCourse(newTitle, newInstructor, newDepartment);
            return true;
        }
        return false;
    }

    // === Deactivate course ===
    public boolean deactivateCourse(String code) {
        Course course = findCourseByCode(code);
        if (course != null && course.isActive()) {
            course.deactivate();
            return true;
        }
        return false;
    }

    // === Search by instructor ===
    public List<Course> findByInstructor(String instructor) {
        List<Course> result = new ArrayList<>();
        for (Course c : courses) {
            if (c.getInstructor().equalsIgnoreCase(instructor)) {
                result.add(c);
            }
        }
        return result;
    }

    // === Search by department ===
    public List<Course> findByDepartment(String dept) {
        List<Course> result = new ArrayList<>();
        for (Course c : courses) {
            if (c.getDepartment().equalsIgnoreCase(dept)) {
                result.add(c);
            }
        }
        return result;
    }
}




