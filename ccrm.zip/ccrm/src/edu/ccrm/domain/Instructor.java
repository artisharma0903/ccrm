package edu.ccrm.domain;

public class Instructor extends Person {
    private String dept;

    public Instructor(int id, String name, String email, String dept) {
        super(id, name, email);
        this.dept = dept;
    }

    @Override
    public String getRole() { return "Instructor"; }

    public String getDept() { return dept; }
}
